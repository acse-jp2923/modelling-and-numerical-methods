# ACSE MNM January2024
Lecture and practise materials for Modelling and Numerical Methods course
